﻿using Microsoft.AspNetCore.Mvc;
using TimeSlot.Models;
using TimeSlot.Services;

namespace TimeSlot.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TimeslotController : ControllerBase
    {
        private readonly ITimeslotService _timeslotService;

        public TimeslotController(ITimeslotService timeslotService)
        {
            _timeslotService = timeslotService;
        }

        [HttpGet("GetTimeslots")]
        public ActionResult<List<Timeslot>> GetTimeslots(DateTime selectedDate, int palletCount)
        {
            var timeslots = _timeslotService.GetTimeslots(selectedDate, palletCount);
            return Ok(timeslots);
        }

        [HttpPost("SetTimeslot")]
        public ActionResult<Timeslot> SetTimeslot(DateTime selectedDate, string from, string to, Guid userId)
        {
            var timeslot = _timeslotService.SetTimeslot(selectedDate, from, to, userId);
            return Ok(timeslot);
        }
    }
}
