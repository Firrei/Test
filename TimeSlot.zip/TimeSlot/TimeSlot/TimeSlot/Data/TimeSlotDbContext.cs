﻿using Microsoft.EntityFrameworkCore;
using TimeSlot.Models;

namespace TimeSlot.Data
{
    public class TimeSlotDbContext : DbContext
    {
        public DbSet<Platform> Platforms { get; set; }
        public DbSet<Gate> Gates { get; set; }
        public DbSet<Timeslot> Timeslots { get; set; }

        public TimeSlotDbContext(DbContextOptions<TimeSlotDbContext> options) : base(options) { }
    }
}
