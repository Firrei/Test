﻿namespace TimeSlot.Models
{
    public class Gate
    {
        public Guid Id { get; set; }
        public int Number { get; set; }
        public Guid PlatformId { get; set; }
        public Platform Platform { get; set; }
    }
}
