﻿using static System.Runtime.InteropServices.JavaScript.JSType;

namespace TimeSlot.Models
{
    public class Platform
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public List<Gate> Gates { get; set; }
    }
}
