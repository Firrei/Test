﻿using TimeSlot.Models;

namespace TimeSlot.Services
{
    public interface ITimeslotService
    {
        List<Timeslot> GetTimeslots(DateTime selectedDate, int palletCount);
        Timeslot SetTimeslot(DateTime selectedDate, string from, string to, Guid userId);
    }
}
