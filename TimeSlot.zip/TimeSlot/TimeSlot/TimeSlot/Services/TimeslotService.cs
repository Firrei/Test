﻿using System;
using TimeSlot.Data;
using TimeSlot.Models;

namespace TimeSlot.Services
{
    public class TimeslotService : ITimeslotService
    {
        private readonly TimeSlotDbContext _dbContext;

        public TimeslotService(TimeSlotDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public List<Timeslot> GetTimeslots(DateTime selectedDate, int palletCount)
        {
            selectedDate = selectedDate.Date;

            var availableTimeslots = _dbContext.Timeslots
                .Where(t => t.Date >= selectedDate && t.GateId == Guid.Empty)
                .OrderBy(t => t.Date)
                .ToList();

            var timeslots = new List<Timeslot>();
            foreach (var timeslot in availableTimeslots)
            {
                var startTime = DateTime.Parse(timeslot.From);
                var endTime = DateTime.Parse(timeslot.To);
                var totalPallets = (endTime - startTime).TotalMinutes / 5; 

                if (totalPallets >= palletCount && totalPallets % 6 == 0)
                {
                    timeslots.Add(timeslot);
                }
            }

            return timeslots;
        }

        public Timeslot SetTimeslot(DateTime selectedDate, string from, string to, Guid userId)
        {
            var timeslot = new Timeslot
            {
                Id = Guid.NewGuid(),
                Date = selectedDate.Date,
                From = from,
                To = to,
                UserId = userId
            };

            _dbContext.Timeslots.Add(timeslot);
            _dbContext.SaveChanges();

            return timeslot;
        }
    }
}
